import { createRoot } from "react-dom/client";
import "./index.css";
import { App } from "./App";
import { AppContextProvider } from "./components/AppContextProvider";

createRoot(document.getElementById("root") as HTMLElement).render(
  <AppContextProvider>
    <App />
  </AppContextProvider>
);
